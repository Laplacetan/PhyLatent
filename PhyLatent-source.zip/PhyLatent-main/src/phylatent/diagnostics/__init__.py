"""PhyLatent diagnostics utilities."""
