"""PhyLatent evaluation utilities."""
